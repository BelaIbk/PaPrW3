#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
#include <time.h>

#define N 1000
//#define N 100000000


int main() {

    double startTime = omp_get_wtime();

    int32_t *array;

    for (int i = 0; i < N; i++){
        array[i] = rand();
    }







    double endTime = omp_get_wtime();
    printf("%2.3fs\n", endTime-startTime);
}